package com.cursoJava.cursoJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
