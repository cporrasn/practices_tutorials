package com.cursoJava.cursoJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoJavaApplication.class, args);
	}

}
